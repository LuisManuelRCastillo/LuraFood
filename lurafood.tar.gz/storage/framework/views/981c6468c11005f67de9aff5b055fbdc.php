<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
       <div class="flex justify-between items-center mb-4">
    <h1 class="text-3xl font-bold text-green-700">Dashboard de Ventas</h1>
    <a href="<?php echo e(route('dashboard.exportar')); ?>" 
       class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded inline-flex items-center">
        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        Exportar a Excel
    </a>
</div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php if (isset($component)) { $__componentOriginal7393cdd37d7c10a83ad0a1866a3b4b6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7393cdd37d7c10a83ad0a1866a3b4b6b = $attributes; } ?>
<?php $component = App\View\Components\Sales::resolve(['pedidos' => $pedidos,'totalVentas' => $totalVentas,'productosMasVendidos' => $productosMasVendidos,'ventasPorDia' => $ventasPorDia,'productoMasVendido' => $productoMasVendido] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sales'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Sales::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7393cdd37d7c10a83ad0a1866a3b4b6b)): ?>
<?php $attributes = $__attributesOriginal7393cdd37d7c10a83ad0a1866a3b4b6b; ?>
<?php unset($__attributesOriginal7393cdd37d7c10a83ad0a1866a3b4b6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7393cdd37d7c10a83ad0a1866a3b4b6b)): ?>
<?php $component = $__componentOriginal7393cdd37d7c10a83ad0a1866a3b4b6b; ?>
<?php unset($__componentOriginal7393cdd37d7c10a83ad0a1866a3b4b6b); ?>
<?php endif; ?>     

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Luis Manuel\Desktop\LuraFood\resources\views/dashboard.blade.php ENDPATH**/ ?>