<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
     
            <style>
                button
                {
                    background: #1b1b18;
                    color: #FDFDFC;
                    font-weight: 600;
                    padding: 0.5rem 1rem;
                    border-radius: 0.375rem;
                    border: none;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }
            </style>
    
    </head>
    <body class="bg-[#FDFDFC] text-[#1b1b18] flex p-6 lg:p-8 items-center lg:justify-center min-h-screen flex-col">

        <?php if (isset($component)) { $__componentOriginal7a9bae6bb1ec4daaf07dde7762fbf48d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a9bae6bb1ec4daaf07dde7762fbf48d = $attributes; } ?>
<?php $component = App\View\Components\StartOrder::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('start-order'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\StartOrder::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a9bae6bb1ec4daaf07dde7762fbf48d)): ?>
<?php $attributes = $__attributesOriginal7a9bae6bb1ec4daaf07dde7762fbf48d; ?>
<?php unset($__attributesOriginal7a9bae6bb1ec4daaf07dde7762fbf48d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a9bae6bb1ec4daaf07dde7762fbf48d)): ?>
<?php $component = $__componentOriginal7a9bae6bb1ec4daaf07dde7762fbf48d; ?>
<?php unset($__componentOriginal7a9bae6bb1ec4daaf07dde7762fbf48d); ?>
<?php endif; ?>
   
    </body>
</html>
<?php /**PATH C:\Users\Luis Manuel\Desktop\LuraFood\resources\views/welcome.blade.php ENDPATH**/ ?>