<a href="/">
   <img src="/assets/img/icono.png" alt="" style="width:100px; height:auto">
</a>
<?php /**PATH C:\Users\Luis Manuel\Desktop\menu-coffee\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>