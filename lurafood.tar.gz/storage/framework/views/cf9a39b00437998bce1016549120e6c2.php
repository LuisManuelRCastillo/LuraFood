<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resumen del Pedido - Menú Coffee</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">

    <div class="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <!-- Mensaje de agradecimiento -->
        <h1 class="text-2xl font-extrabold text-center text-green-600 mb-6">
            ¡Gracias por tu compra,  <?php echo e($cliente['nombre']); ?>!
            
        </h1>

        <!-- Resumen del pedido -->
        <h2 class="text-xl font-bold text-gray-800 mb-4 text-center">Resumen del Pedido</h2>

        <p class="text-gray-700 text-center mb-6">
            <strong>Cliente:</strong> <?php echo e($cliente['nombre']); ?> <br>
            <span class="text-sm text-gray-500">(<?php echo e($cliente['email']); ?>)</span>
        </p>

        <ul class="divide-y divide-gray-200 mb-6">
            <?php $__currentLoopData = $pedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="py-2 flex justify-between text-gray-700">
                    <span><?php echo e($item['nombre']); ?> x <?php echo e($item['quantity']); ?></span>
                    <span class="font-semibold">$<?php echo e($item['subtotal']); ?></span>
                </li>
                 <?php if(isset($item['leche'])): ?>
                        <p class="text-sm text-gray-500">Leche: <?php echo e($item['leche']); ?></p>
                    <?php endif; ?>
                <?php if(isset($item['extras']) && count($item['extras']) > 0): ?>
<p class="text-sm text-gray-500">Extras: <?php echo e(implode(', ', $item['extras'])); ?></p>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <p class="text-lg font-bold text-gray-800 text-right mb-6">
            Total: $<?php echo e(array_sum(array_column($pedido, 'subtotal'))); ?>

        </p>

        <!-- Botón finalizar -->
        <form action="<?php echo e(route('pedidos.finalizar')); ?>" method="POST" class="text-center">
            <?php echo csrf_field(); ?>
            <button type="submit" 
                    class="w-full px-4 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition">
                Finalizar Pedido
            </button>
        </form>
    </div>

</body>
</html>
<?php /**PATH C:\Users\Luis Manuel\Desktop\menu-coffee\resources\views/Orders/resumeOrder.blade.php ENDPATH**/ ?>