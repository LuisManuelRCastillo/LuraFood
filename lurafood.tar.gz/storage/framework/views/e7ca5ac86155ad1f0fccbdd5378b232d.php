<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="text-3xl font-bold text-green-700">Genera tu QR</h1>
     <?php $__env->endSlot(); ?>

    <div class="max-w-5xl mx-auto py-10">
        <div class="flex flex-col md:flex-row gap-8">
            
            <div class="md:w-1/2 bg-white p-6 rounded-lg shadow">
                <h2 class="text-2xl font-bold mb-6">Generar QR por Mesa</h2>

                <form method="GET" action="<?php echo e(route('qr')); ?>">
                    <label for="mesa" class="block text-gray-700 font-semibold mb-2">Número o nombre de mesa</label>
                    <input type="text" name="mesa" id="mesa" value="<?php echo e(old('mesa', $mesa)); ?>"
                           placeholder="Ejemplo: 1, Terraza, VIP-2..."
                           class="w-full border-gray-300 rounded-lg shadow-sm focus:ring focus:ring-green-300 mb-4">

                    <button type="submit"
                            class="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg">
                        Generar QR
                    </button>
                </form>
            </div>

            
            <?php if($qr): ?>
                <div class="md:w-1/2 flex flex-col items-center justify-center bg-white p-6 rounded-lg shadow">
                   
                    <div class="inline-block p-4 bg-white rounded-lg shadow mb-4">
                        <img src="data:image/png;base64,<?php echo e($qr); ?>" alt="QR Mesa <?php echo e($mesa); ?>">
                    </div>
                    <p class="text-blue-600 text-sm break-all mb-2">
                         <h2 class="text-lg font-bold mb-2">QR para la mesa: <?php echo e($mesa); ?></h2>
                    </p>
                    <a href="data:image/png;base64,<?php echo e($qr); ?>"
                       download="qr-mesa-<?php echo e($mesa); ?>.png"
                       class="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        Descargar QR
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Luis Manuel\Desktop\LuraFood\resources\views/QrGenerator/indexQr.blade.php ENDPATH**/ ?>