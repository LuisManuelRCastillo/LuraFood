<div>
    <?php if(session('pedido') && count(session('pedido')) > 0): ?>
        <ul class="space-y-3">
            <?php $__currentLoopData = session('pedido'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex justify-between items-center border-b pb-2">
                <div>
                    <p class="font-semibold">
                        <?php echo e($item['nombre']); ?>  <?php if(isset($item['tamano']) && !empty($item['tamano'])): ?>
                            (<?php echo e(ucfirst($item['tamano'])); ?>)
                        <?php endif; ?> x <?php echo e($item['quantity']); ?>

                    </p>
                    <?php if(isset($item['leche'])): ?>
                        <p class="text-sm text-gray-500">Leche: <?php echo e($item['leche']); ?></p>
                    <?php endif; ?>
                    <?php if(isset($item['extras']) && count($item['extras']) > 0): ?>
                        <p class="text-sm text-gray-500">Extras: <?php echo e(implode(', ', $item['extras'])); ?></p>
                    <?php endif; ?>
                </div>
                <div class="flex items-center space-x-2">
                    <form action="<?php echo e(route('pedido.menos', $key)); ?>" method="POST" class="form-menos">
                        <?php echo csrf_field(); ?>
                        <button class="px-2 bg-gray-200 rounded">-</button>
                    </form>
                    <span class="font-bold"><?php echo e($item['quantity']); ?></span>
                    <form action="<?php echo e(route('pedido.mas', $key)); ?>" method="POST" class="form-mas">
                        <?php echo csrf_field(); ?>
                        <button class="px-2 bg-gray-200 rounded">+</button>
                    </form>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="font-bold text-green-600">$<?php echo e($item['subtotal']); ?></span>
                    <a href="<?php echo e(route('pedidos.eliminar', $item['product_id'])); ?>" class="btn-eliminar text-red-600 hover:text-red-800 text-xl">&times;</a>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <p class="font-bold mt-4 text-lg">Total: $<?php echo e(array_sum(array_column(session('pedido'), 'subtotal'))); ?></p>
        <a href="<?php echo e(route('pedidos.cliente')); ?>" class="mt-4 inline-block w-full text-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            Ir al pago
        </a>
    <?php else: ?>
        <p>No hay productos en el carrito</p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Luis Manuel\Desktop\menu-coffee\resources\views/components/cart.blade.php ENDPATH**/ ?>