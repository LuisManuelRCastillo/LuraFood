<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductsModel extends Model
{
    // Definir la tabla asociada
    protected $table = 'productos';
}
