<input type="checkbox" {!! $attributes->merge(['class' => 'rounded border-gray-300 text-green-600 shadow-sm focus:ring-green-500']) !!}>
