<a href="/">
   <img src="/assets/img/icono.png" alt="" style="width:100px; height:auto">
</a>
